final class class_210
  implements class_1412
{
  class_210(class_206 paramclass_206) {}
  
  public final boolean a1()
  {
    return false;
  }
  
  public final void a(class_1363 paramclass_1363, class_939 paramclass_939)
  {
    if (paramclass_939.a())
    {
      if (this.field_91.a11().jdField_field_795_of_type_Int == 0)
      {
        switch (class_206.a86(this.field_91))
        {
        case 1: 
          if (this.field_91.a11().jdField_field_795_of_type_Boolean)
          {
            this.field_91.a11().jdField_field_795_of_type_Boolean = false;
            return;
          }
          this.field_91.a11().jdField_field_795_of_type_Int = class_206.a86(this.field_91);
          return;
        case 2: 
          if (this.field_91.a11().field_796)
          {
            this.field_91.a11().field_796 = false;
            return;
          }
          this.field_91.a11().jdField_field_795_of_type_Int = class_206.a86(this.field_91);
          return;
        case 4: 
          if (this.field_91.a11().field_797)
          {
            this.field_91.a11().field_797 = false;
            return;
          }
          this.field_91.a11().jdField_field_795_of_type_Int = class_206.a86(this.field_91);
        }
        return;
      }
      this.field_91.a11().jdField_field_795_of_type_Int = 0;
    }
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_210
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */