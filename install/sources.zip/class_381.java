public final class class_381
  extends class_1003
{
  private static final long serialVersionUID = -5677566600649358934L;
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_381
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */