public final class class_10
{
  final class_748 jdField_field_431_of_type_Class_748;
  long jdField_field_431_of_type_Long = -1L;
  long jdField_field_432_of_type_Long;
  boolean jdField_field_431_of_type_Boolean = false;
  boolean jdField_field_432_of_type_Boolean;
  public boolean field_433;
  
  public class_10(class_748 paramclass_748)
  {
    this.field_432 = -1L;
    this.jdField_field_431_of_type_Class_748 = paramclass_748;
    paramclass_748.a140();
    this.jdField_field_431_of_type_Long = class_744.a4();
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_10
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */