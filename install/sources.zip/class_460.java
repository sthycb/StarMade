import java.util.HashMap;
import org.schema.schine.ai.stateMachines.FSMException;

public final class class_460
  extends class_983
{
  public class_747 field_163;
  
  public class_460(class_989 paramclass_989)
  {
    super(paramclass_989, true);
    b2(false);
  }
  
  public final void a()
  {
    this.jdField_field_163_of_type_Class_997.a2().a1(new class_395());
  }
  
  public final void b()
  {
    try
    {
      this.jdField_field_163_of_type_Class_997.a2().a1(new class_393());
      return;
    }
    catch (FSMException localFSMException)
    {
      localFSMException;
    }
  }
  
  public final void c()
  {
    try
    {
      this.jdField_field_163_of_type_Class_997.a2().a1(new class_375());
      return;
    }
    catch (FSMException localFSMException)
    {
      localFSMException;
    }
  }
  
  public final class_371 a1()
  {
    return (class_371)super.a6();
  }
  
  public static boolean a2()
  {
    return false;
  }
  
  public final void d()
  {
    try
    {
      this.jdField_field_163_of_type_Class_997.a2().a1(new class_385());
      return;
    }
    catch (FSMException localFSMException)
    {
      localFSMException;
    }
  }
  
  public final void e()
  {
    try
    {
      this.jdField_field_163_of_type_Class_997.a2().a1(new class_383());
      return;
    }
    catch (FSMException localFSMException)
    {
      localFSMException;
    }
  }
  
  public final void a3(boolean paramBoolean)
  {
    if ((!(this.jdField_field_163_of_type_Class_997.a2().a() instanceof class_405)) && (!paramBoolean)) {
      try
      {
        this.jdField_field_163_of_type_Class_997.a2().a1(new class_381());
        return;
      }
      catch (FSMException localFSMException) {}
    }
  }
  
  public final void f()
  {
    if ((this.jdField_field_163_of_type_Class_997.a2().a() instanceof class_454)) {
      ((class_454)this.jdField_field_163_of_type_Class_997.a2().a()).a2();
    }
  }
  
  protected final void a4(HashMap paramHashMap)
  {
    paramHashMap.put("basic_tutorial", new class_462(this.jdField_field_163_of_type_Class_989, this));
  }
  
  protected final String a5()
  {
    return "basic_tutorial";
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_460
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */