import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

final class class_495
  implements ActionListener
{
  class_495(class_697 paramclass_697) {}
  
  public final void actionPerformed(ActionEvent paramActionEvent)
  {
    this.field_811.dispose();
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_495
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */