import java.nio.FloatBuffer;

public abstract interface class_378
{
  public abstract void a(int paramInt, byte paramByte1, short paramShort, byte paramByte2, byte paramByte3, byte paramByte4, byte paramByte5, byte paramByte6, FloatBuffer paramFloatBuffer);
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_378
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */