import javax.vecmath.Vector3f;
import javax.vecmath.Vector4f;

final class class_352
  implements class_955
{
  Vector3f jdField_field_89_of_type_JavaxVecmathVector3f = new Vector3f();
  float jdField_field_89_of_type_Float;
  int jdField_field_89_of_type_Int = 0;
  public Vector4f field_89;
  
  private class_352()
  {
    this.jdField_field_89_of_type_JavaxVecmathVector4f = new Vector4f();
  }
  
  public final Vector3f a83()
  {
    return this.jdField_field_89_of_type_JavaxVecmathVector3f;
  }
  
  public final int a105(class_1380 paramclass_1380)
  {
    return this.jdField_field_89_of_type_Int;
  }
  
  public final float a106(long paramLong)
  {
    return this.jdField_field_89_of_type_Float;
  }
  
  public final Vector4f a63()
  {
    return this.jdField_field_89_of_type_JavaxVecmathVector4f;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_352
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */