public abstract interface class_80
  extends class_74
{
  public abstract void fromTagStructure(class_69 paramclass_69);
  
  public abstract class_69 toTagStructure();
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_80
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */