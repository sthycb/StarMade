public final class class_336
  extends class_12
{
  private final class_181 field_4 = new class_181(this.field_4, paramclass_340, this);
  
  public class_336(class_371 paramclass_371, class_340 paramclass_340)
  {
    super(paramclass_371);
    this.field_4.c();
  }
  
  public final boolean a1()
  {
    return false;
  }
  
  public final void handleKeyEvent() {}
  
  public final class_1363 a3()
  {
    return this.field_4;
  }
  
  public final void a2()
  {
    this.field_4.a14().field_4.field_4.jdField_field_4_of_type_Class_427.a13(500);
    this.field_4.a14().field_4.field_4.jdField_field_4_of_type_Class_427.e2(false);
  }
  
  public final void a(class_1363 paramclass_1363, class_939 paramclass_939)
  {
    if (paramclass_939.a())
    {
      if (paramclass_1363.b29().equals("OK"))
      {
        this.field_4.a14().field_4.field_4.jdField_field_4_of_type_Class_338.field_4 = this.field_4.field_89;
        this.field_4.a27().a92().a18().a23().e();
        d();
        return;
      }
      if ((paramclass_1363.b29().equals("CANCEL")) || (paramclass_1363.b29().equals("X"))) {
        d();
      }
    }
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_336
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */