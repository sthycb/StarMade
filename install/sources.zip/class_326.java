final class class_326
  implements class_952
{
  class_326(class_322 paramclass_322) {}
  
  public final void a(String paramString)
  {
    try
    {
      ((class_320)this.field_129.field_4).field_682 = Integer.parseInt(paramString);
      return;
    }
    catch (Exception localException) {}
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_326
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */