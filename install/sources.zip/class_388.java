public final class class_388
{
  float[] jdField_field_781_of_type_ArrayOfFloat = new float[6];
  public byte[] field_781;
  public float[] field_782;
  int jdField_field_781_of_type_Int;
  
  public class_388(int paramInt)
  {
    this.jdField_field_781_of_type_Int = paramInt;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_388
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */