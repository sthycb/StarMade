import org.schema.schine.network.client.ClientState;

public final class class_248
  extends class_959
  implements Comparable
{
  private final class_781 field_89;
  
  public class_248(class_1363 paramclass_13631, class_1363 paramclass_13632, class_781 paramclass_781, ClientState paramClientState)
  {
    super(paramclass_13631, paramclass_13632, paramClientState);
    this.field_89 = paramclass_781;
  }
  
  public final class_781 a108()
  {
    return this.field_89;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_248
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */