import org.schema.game.common.controller.EditableSendableSegmentController;

public abstract interface class_457
{
  public abstract class_48 a();
  
  public abstract EditableSendableSegmentController a1();
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_457
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */