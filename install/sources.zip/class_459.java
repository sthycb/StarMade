public final class class_459
  extends class_16
  implements class_1412
{
  public class_461 field_4 = new class_461();
  public class_461 field_5 = new class_461();
  public class_461 field_6 = new class_461();
  public boolean field_7;
  
  public class_459(class_371 paramclass_371)
  {
    super(paramclass_371);
    new class_461();
    this.field_7 = true;
  }
  
  public final void a(class_1363 paramclass_1363, class_939 paramclass_939) {}
  
  public final int a28()
  {
    return this.field_6.field_802;
  }
  
  public final int b6()
  {
    return this.field_5.field_802;
  }
  
  public final class_48 a35()
  {
    return new class_48(this.field_4.field_802, this.field_5.field_802, this.field_6.field_802);
  }
  
  public final int c4()
  {
    return this.field_4.field_802;
  }
  
  public final boolean a1()
  {
    return false;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_459
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */