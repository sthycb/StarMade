import com.bulletphysics.linearmath.Transform;

final class class_473
  implements class_1382
{
  class_473(Transform paramTransform) {}
  
  public final Transform getWorldTransform()
  {
    return this.field_116;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_473
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */