import org.schema.schine.network.client.ClientState;

public final class class_259
  extends class_196
{
  private class_928 field_89;
  
  public class_259(ClientState paramClientState, class_1412 paramclass_1412, Object paramObject1, Object paramObject2, class_1077 paramclass_1077)
  {
    super(paramClientState, paramclass_1412, paramObject1, paramObject2);
    this.jdField_field_89_of_type_Class_928 = new class_928(paramClientState);
    this.jdField_field_89_of_type_Class_928.field_90 = "";
    this.jdField_field_89_of_type_Class_928.field_89 = paramclass_1077;
  }
  
  public final void a2()
  {
    super.a2();
    this.jdField_field_89_of_type_Class_928.a2();
  }
  
  public final void c()
  {
    super.c();
    this.jdField_field_89_of_type_Class_928.c();
    this.jdField_field_89_of_type_Class_972.a9(this.jdField_field_89_of_type_Class_928);
    this.jdField_field_89_of_type_Class_928.a161(55.0F, 181.0F, 0.0F);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_259
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */