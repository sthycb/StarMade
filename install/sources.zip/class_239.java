import org.schema.game.common.controller.EditableSendableSegmentController;

final class class_239
{
  class_229 jdField_field_652_of_type_Class_229;
  EditableSendableSegmentController jdField_field_652_of_type_OrgSchemaGameCommonControllerEditableSendableSegmentController;
  
  public class_239(class_229 paramclass_229, EditableSendableSegmentController paramEditableSendableSegmentController)
  {
    this.jdField_field_652_of_type_Class_229 = paramclass_229;
    this.jdField_field_652_of_type_OrgSchemaGameCommonControllerEditableSendableSegmentController = paramEditableSendableSegmentController;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_239
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */