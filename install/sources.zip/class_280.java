import java.util.Collection;
import org.schema.schine.network.client.ClientState;

final class class_280
  extends class_160
{
  class_280(ClientState paramClientState)
  {
    super(paramClientState, false);
  }
  
  public final Collection a50()
  {
    return ((class_371)a24()).a20().a122().field_1043;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_280
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */