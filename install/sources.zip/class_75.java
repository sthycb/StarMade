import com.bulletphysics.linearmath.Transform;

public abstract interface class_75
  extends class_74, class_1382, class_1421
{
  public abstract String a();
  
  public abstract String b();
  
  public abstract float b1();
  
  public abstract Transform getWorldTransformClient();
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_75
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */