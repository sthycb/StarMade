public final class class_47
{
  public float field_471;
  public float field_472;
  public float field_473;
  public float field_474;
  
  public class_47()
  {
    this.field_471 = 0.0F;
    this.field_472 = 0.0F;
    this.field_473 = 0.0F;
    this.field_474 = 0.0F;
  }
  
  public class_47(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    this.field_471 = paramFloat1;
    this.field_472 = paramFloat2;
    this.field_473 = paramFloat3;
    this.field_474 = paramFloat4;
  }
  
  public final String toString()
  {
    return "[a" + this.field_474 + ", x" + this.field_471 + ", y" + this.field_472 + ", z" + this.field_473 + "]";
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_47
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */