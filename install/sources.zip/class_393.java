public final class class_393
  extends class_1003
{
  private static final long serialVersionUID = 5630908075495941307L;
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_393
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */