import java.util.Comparator;

final class class_23
  implements Comparator
{
  class_23(class_20 paramclass_20) {}
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_23
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */