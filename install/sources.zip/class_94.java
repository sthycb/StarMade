final class class_94
{
  class_94(class_773 paramclass_773) {}
  
  public final String toString()
  {
    if (this.field_620.d8().length() > 0) {
      return this.field_620.a44().toString();
    }
    return "no home";
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_94
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */