import java.io.DataOutputStream;

public abstract interface class_67
{
  public abstract void writeToTag(DataOutputStream paramDataOutputStream);
  
  public abstract byte getFactoryId();
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_67
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */