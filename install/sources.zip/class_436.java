public final class class_436
  extends class_12
{
  private class_109 field_4 = new class_109(paramclass_371, this);
  
  public class_436(class_371 paramclass_371)
  {
    super(paramclass_371);
    this.field_4.e();
  }
  
  public final void a(class_1363 paramclass_1363, class_939 paramclass_939)
  {
    if ((paramclass_939.a()) && ((paramclass_1363.b29().equals("OK")) || (paramclass_1363.b29().equals("CANCEL")) || (paramclass_1363.b29().equals("X")))) {
      d();
    }
  }
  
  public final boolean a1()
  {
    return false;
  }
  
  public final void handleKeyEvent() {}
  
  public final class_1363 a3()
  {
    return this.field_4;
  }
  
  public final void a2()
  {
    this.field_4.a14().field_4.field_4.field_4.a13(500);
    this.field_4.a14().field_4.field_4.field_4.e2(false);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_436
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */