public final class class_62
  extends class_59
{
  private static final long serialVersionUID = -5610119959656087076L;
  
  public class_62(Object paramObject, class_64 paramclass_64)
  {
    super(paramObject, paramclass_64);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_62
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */