final class class_21
{
  class_748 jdField_field_439_of_type_Class_748;
  long jdField_field_439_of_type_Long;
  
  public class_21(class_748 paramclass_748, long paramLong)
  {
    this.jdField_field_439_of_type_Class_748 = paramclass_748;
    this.jdField_field_439_of_type_Long = paramLong;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_21
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */