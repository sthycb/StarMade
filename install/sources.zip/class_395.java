public final class class_395
  extends class_1003
{
  private static final long serialVersionUID = -6970548770389232891L;
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_395
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */