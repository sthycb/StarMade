import java.util.HashMap;

final class class_92
{
  class_92(class_773 paramclass_773) {}
  
  public final String toString()
  {
    if (this.field_619.a3() < 0) {
      return "[NPC]";
    }
    return "[" + this.field_619.a162().size() + "]";
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_92
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */