final class class_145
  implements class_1412
{
  class_145(class_156 paramclass_156) {}
  
  public final boolean a1()
  {
    return false;
  }
  
  public final void a(class_1363 paramclass_1363, class_939 paramclass_939)
  {
    if (paramclass_939.a())
    {
      this.field_91.a29(true);
      (paramclass_1363 = new class_831(this, (class_371)this.field_91.a24(), "Edit Role Name", "Enter a new name for this Role", class_156.a46(this.field_91))).a10(new class_833());
      paramclass_1363.c1();
    }
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_145
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */