import org.schema.schine.network.client.ClientState;

final class class_105
  extends class_934
{
  public class_105(class_112 paramclass_112, ClientState paramClientState, int paramInt)
  {
    super(paramClientState, 120, 20, class_112.a20(paramclass_112).a180().a26()[paramInt], paramclass_112);
    this.field_89 = new Integer(paramInt);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_105
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */