public final class class_22
{
  public final class_20 field_440;
  public final class_672 field_440;
  
  public class_22(class_20 paramclass_20, class_672 paramclass_672)
  {
    this.jdField_field_440_of_type_Class_20 = paramclass_20;
    this.jdField_field_440_of_type_Class_672 = paramclass_672;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_22
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */