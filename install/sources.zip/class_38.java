public final class class_38
{
  public static String field_461 = "config/mainConfig.xml";
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_38
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */