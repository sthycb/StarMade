import org.schema.schine.network.client.ClientState;

final class class_246
  extends class_1404
{
  class_246(class_244 paramclass_244, ClientState paramClientState)
  {
    super(paramClientState);
  }
  
  protected final boolean b3()
  {
    return this.field_89.field_89.b2();
  }
  
  protected final void f()
  {
    this.field_89.field_89.a189(false, 1);
  }
  
  protected final void e()
  {
    this.field_89.field_89.a189(true, 1);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_246
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */