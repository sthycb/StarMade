final class class_410
  extends class_14
{
  class_410(class_423 paramclass_423, class_371 paramclass_371, Object paramObject1, Object paramObject2, String paramString)
  {
    super(paramclass_371, 5, paramObject1, paramObject2, paramString);
  }
  
  public final boolean a1()
  {
    return false;
  }
  
  public final void onFailedTextCheck(String paramString) {}
  
  public final String handleAutoComplete(String paramString1, class_1079 paramclass_1079, String paramString2)
  {
    return null;
  }
  
  public final String[] getCommandPrefixes()
  {
    return null;
  }
  
  public final boolean a7(String paramString)
  {
    return this.field_4.a20().a141().b39(paramString);
  }
  
  public final void a2()
  {
    this.field_4.e2(false);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_410
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */