import java.util.ArrayList;
import org.schema.schine.network.client.ClientState;

final class class_99
  extends class_961
{
  class_99(ClientState paramClientState, class_964 paramclass_964, class_1363 paramclass_13631, class_1363 paramclass_13632)
  {
    super(paramClientState, paramclass_964, paramclass_13631, paramclass_13632);
  }
  
  protected final boolean b3()
  {
    return ((class_371)a24()).b().isEmpty();
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_99
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */