import java.util.ArrayList;
import org.schema.schine.network.Identifiable;
import org.schema.schine.network.objects.Sendable;

public abstract interface class_365
  extends Identifiable
{
  public abstract boolean isClientOwnObject();
  
  public abstract ArrayList a26();
  
  public abstract void a27(class_941 paramclass_941, class_755 paramclass_755);
  
  public abstract boolean isHidden();
  
  public abstract void a28(class_748 paramclass_748, Sendable paramSendable, class_48 paramclass_48);
  
  public abstract void a29(class_748 paramclass_748, boolean paramBoolean);
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_365
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */