public abstract interface class_361
{
  public abstract class_876 a();
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_361
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */