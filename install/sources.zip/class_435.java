public final class class_435
  extends class_454
{
  private static final long serialVersionUID = 438885771406304916L;
  
  public class_435(class_981 paramclass_981, String paramString, class_371 paramclass_371)
  {
    super(paramclass_981, paramString, paramclass_371);
    this.field_162 = true;
  }
  
  protected final boolean a()
  {
    return this.field_128.d2();
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_435
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */