import java.io.PrintStream;
import java.util.List;
import org.schema.game.client.view.cubes.CubeOptOptMesh;
import org.schema.schine.graphicsengine.forms.Mesh;

final class class_321
  extends class_72
{
  public final void a(class_73 paramclass_73)
  {
    System.err.println("Init Cube MESH");
    class_969.a2().a4("Box").a152().get(0);
    CubeOptOptMesh.d();
    System.err.println("Init Cube MESH DONE");
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_321
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */