import org.schema.schine.network.client.ClientState;

final class class_179
  extends class_1404
{
  private long jdField_field_89_of_type_Long;
  
  public class_179(class_181 paramclass_181, ClientState paramClientState, long paramLong)
  {
    super(paramClientState);
    this.jdField_field_89_of_type_Long = paramLong;
  }
  
  protected final void e()
  {
    this.jdField_field_89_of_type_Class_181.field_89.a(true, this.jdField_field_89_of_type_Long);
  }
  
  protected final void f()
  {
    this.jdField_field_89_of_type_Class_181.field_89.a(false, this.jdField_field_89_of_type_Long);
  }
  
  protected final boolean b3()
  {
    long l = this.jdField_field_89_of_type_Long;
    return (this.jdField_field_89_of_type_Class_181.field_89.field_684 & l) == l;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_179
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */