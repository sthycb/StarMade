final class class_441
  implements class_481
{
  public final void a(short paramShort) {}
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_441
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */