import java.util.Collection;
import org.schema.schine.network.client.ClientState;

final class class_276
  extends class_160
{
  class_276(ClientState paramClientState)
  {
    super(paramClientState, true);
  }
  
  public final Collection a50()
  {
    return ((class_371)a24()).a20().a122().field_1045;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_276
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */