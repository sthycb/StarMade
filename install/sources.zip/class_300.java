public class class_300
  extends class_403
{
  int field_128;
  private static final long serialVersionUID = -2062138621427988662L;
  
  public class_300(class_981 paramclass_981, class_371 paramclass_371, String paramString, int paramInt)
  {
    super(paramclass_981, paramString, paramclass_371);
    this.field_128 = paramInt;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_300
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */