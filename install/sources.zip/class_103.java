final class class_103
{
  class_103(class_773 paramclass_773) {}
  
  public final String toString()
  {
    return this.field_623.a();
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_103
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */