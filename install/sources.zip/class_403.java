public abstract class class_403
  extends class_454
{
  private static final long serialVersionUID = 4508994008546152897L;
  protected long field_128;
  
  public class_403(class_981 paramclass_981, String paramString, class_371 paramclass_371)
  {
    super(paramclass_981, paramString, paramclass_371);
  }
  
  protected boolean a()
  {
    this.field_128.a4().a5();
    class_460.a2();
    return this.jdField_field_128_of_type_Boolean;
  }
  
  public boolean c()
  {
    this.jdField_field_128_of_type_Long = System.currentTimeMillis();
    return super.c();
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_403
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */