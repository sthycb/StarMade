public final class class_348
  extends class_16
  implements class_1412
{
  public class_348(class_371 paramclass_371)
  {
    super(paramclass_371);
  }
  
  public final void a(class_1363 paramclass_1363, class_939 paramclass_939) {}
  
  public final boolean a1()
  {
    return false;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_348
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */