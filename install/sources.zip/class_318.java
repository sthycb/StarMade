final class class_318
  implements class_952
{
  class_318(class_314 paramclass_314) {}
  
  public final void a(String paramString)
  {
    try
    {
      ((class_320)this.field_129.field_4).field_682 = Integer.parseInt(paramString);
      return;
    }
    catch (Exception localException) {}
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_318
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */