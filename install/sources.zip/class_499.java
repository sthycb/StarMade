import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

final class class_499
  implements ActionListener
{
  class_499(class_699 paramclass_699) {}
  
  public final void actionPerformed(ActionEvent paramActionEvent)
  {
    class_699.c(this.field_814);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_499
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */