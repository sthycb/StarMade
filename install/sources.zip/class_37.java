import java.io.Serializable;
import java.rmi.Remote;

public final class class_37
  implements Serializable, Cloneable, Remote
{
  private static final long serialVersionUID = 65793L;
  private float[] field_460 = new float[16];
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_37
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */