import org.schema.game.common.data.world.Segment;

public final class class_446
  extends class_454
{
  private static final long serialVersionUID = 438885771406304916L;
  
  public class_446(class_981 paramclass_981, String paramString, class_371 paramclass_371)
  {
    super(paramclass_981, paramString, paramclass_371);
    this.field_162 = true;
  }
  
  protected final boolean a()
  {
    if (this.field_128.a4().a5().field_163 == null) {
      a8().a4().a2().a1(new class_389());
    }
    class_796 localclass_796;
    if (((localclass_796 = this.field_128.a14().a18().a79().a60().a51().a40()) != null) && (localclass_796.a7().a15() != null)) {
      return localclass_796.a7().a15() == this.field_128.a4().a5().field_163;
    }
    return false;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_446
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */