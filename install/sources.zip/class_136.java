import org.schema.schine.network.client.ClientState;

final class class_136
  extends class_934
{
  class_136(class_141 paramclass_141, ClientState paramClientState, Object paramObject, class_1412 paramclass_1412)
  {
    super(paramClientState, 200, 20, paramObject, paramclass_1412);
  }
  
  public final void b()
  {
    if ((((class_371)a24()).a50() != null) && (this.field_89.field_89.getFactionId() == ((class_371)a24()).a20().h1()) && (((this.field_89.field_89 instanceof class_864)) || ((this.field_89.field_89 instanceof class_737)))) {
      super.b();
    }
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_136
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */