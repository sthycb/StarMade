final class class_494
  implements class_532
{
  class_494(class_496 paramclass_496, class_561 paramclass_561) {}
  
  public final void a()
  {
    class_700.a(this.jdField_field_168_of_type_Class_496.field_812).a1(this.jdField_field_168_of_type_Class_561);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_494
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */