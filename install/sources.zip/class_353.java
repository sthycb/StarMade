public final class class_353
{
  public long field_688;
  public long field_689;
  public long field_690;
  public long field_691;
  public long field_692;
  public long field_693;
  public long field_694;
  public long field_695;
  long field_696;
  public long field_697;
  public long field_698;
  public long field_699;
  public long field_700;
  public long field_701;
  public long field_702;
  public long field_703;
  public int field_688;
  public int field_689;
  public long field_704;
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_353
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */