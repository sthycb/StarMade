import java.util.Comparator;

 enum class_180
{
  Comparator jdField_field_627_of_type_JavaUtilComparator;
  
  private class_180(Comparator paramComparator)
  {
    this.jdField_field_627_of_type_JavaUtilComparator = paramComparator;
  }
  
  static
  {
    jdField_field_627_of_type_Class_180 = new class_180("NAME", 0, new class_178());
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_180
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */