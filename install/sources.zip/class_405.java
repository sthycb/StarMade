public final class class_405
  extends class_999
{
  private static final long serialVersionUID = -334972996033688715L;
  
  public class_405(class_981 paramclass_981)
  {
    super(paramclass_981);
  }
  
  public final boolean c()
  {
    return true;
  }
  
  public final boolean b()
  {
    return true;
  }
  
  public final boolean d()
  {
    return true;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_405
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */