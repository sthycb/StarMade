public enum class_369
{
  private final String jdField_field_764_of_type_JavaLangString;
  private final class_369 field_769;
  private final int jdField_field_764_of_type_Int;
  
  private class_369(String paramString, class_369 paramclass_369, int paramInt)
  {
    this.jdField_field_764_of_type_JavaLangString = paramString;
    this.field_769 = paramclass_369;
    this.jdField_field_764_of_type_Int = paramInt;
  }
  
  public final String a()
  {
    return this.jdField_field_764_of_type_JavaLangString;
  }
  
  public final int a1()
  {
    return this.jdField_field_764_of_type_Int;
  }
  
  public final class_369 a2()
  {
    return this.field_769;
  }
  
  public final boolean a3()
  {
    return this.field_769 == null;
  }
  
  static
  {
    jdField_field_764_of_type_Class_369 = new class_369("GENERAL", 0, "General Controls", null, 0);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_369
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */