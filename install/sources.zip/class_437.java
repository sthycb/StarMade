public final class class_437
  extends class_438
{
  public final String getUniqueIdentifier()
  {
    return "SYS_" + this.field_136;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_437
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */