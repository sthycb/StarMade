import java.io.Serializable;

public enum class_64
  implements Serializable
{
  private String jdField_field_528_of_type_JavaLangString;
  
  private class_64(String paramString)
  {
    this.jdField_field_528_of_type_JavaLangString = paramString;
  }
  
  public final String toString()
  {
    return this.jdField_field_528_of_type_JavaLangString;
  }
  
  static
  {
    jdField_field_528_of_type_Class_64 = new class_64("SPRITEPATH", 0, "path");
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_64
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */