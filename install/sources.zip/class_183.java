import org.schema.schine.network.client.ClientState;

public final class class_183
  extends class_972
{
  private class_968 field_89;
  
  public class_183(ClientState paramClientState, class_968 paramclass_968)
  {
    super(class_969.a2().a5("inventory-slots-gui-"), paramClientState);
    this.field_89 = paramclass_968;
    this.field_96 = true;
  }
  
  public final float a3()
  {
    return 360.0F;
  }
  
  public final float b1()
  {
    return 503.0F;
  }
  
  public final boolean a_()
  {
    return (super.a_()) && (this.field_89.a_());
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_183
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */