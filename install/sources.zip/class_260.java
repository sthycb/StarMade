import org.schema.schine.network.client.ClientState;

final class class_260
  extends class_196
{
  public class_260(ClientState paramClientState, class_1412 paramclass_1412, Object paramObject1, Object paramObject2)
  {
    super(paramClientState, paramclass_1412, paramObject1, paramObject2);
    this.field_89 = false;
  }
  
  public final void c()
  {
    super.c();
    class_262 localclass_262;
    (localclass_262 = new class_262(a24())).c();
    this.field_89.a9(localclass_262);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_260
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */