import java.util.Observable;

public final class class_44
  extends Observable
{
  private class_371 field_466;
  
  public class_44(class_371 paramclass_371)
  {
    this.field_466 = paramclass_371;
  }
  
  public final class_371 a()
  {
    return this.field_466;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_44
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */