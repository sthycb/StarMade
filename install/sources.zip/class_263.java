import java.util.List;
import org.schema.schine.network.client.ClientState;

public final class class_263
  extends class_196
{
  private class_928 jdField_field_89_of_type_Class_928;
  private class_951 jdField_field_89_of_type_Class_951;
  
  public class_263(ClientState paramClientState, class_1412 paramclass_1412, Object paramObject1, Object paramObject2, class_951 paramclass_951)
  {
    super(paramClientState, paramclass_1412, paramObject1, paramObject2);
    this.jdField_field_89_of_type_Class_928 = new class_928(paramClientState, true);
    this.jdField_field_89_of_type_Class_928.field_90 = "";
    this.jdField_field_89_of_type_Class_928.jdField_field_89_of_type_Class_951 = paramclass_951;
    this.jdField_field_89_of_type_Class_951 = paramclass_951;
  }
  
  public final void a2()
  {
    super.a2();
    this.jdField_field_89_of_type_Class_928.a2();
  }
  
  public final void c()
  {
    super.c();
    this.jdField_field_89_of_type_Class_928.c();
    this.jdField_field_89_of_type_Class_972.a9(this.jdField_field_89_of_type_Class_928);
    this.jdField_field_89_of_type_Class_928.c12(this.jdField_field_89_of_type_Class_1414.a83());
    this.jdField_field_89_of_type_Class_930.a161(2.0F, 110.0F, 0.0F);
    this.jdField_field_89_of_type_Class_930.field_90.add(new class_265(this));
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_263
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */