import java.util.Comparator;

final class class_176
  implements Comparator
{}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_176
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */