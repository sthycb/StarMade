import org.schema.game.common.controller.SegmentController;

public abstract interface class_197
{
  public abstract SegmentController a();
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_197
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */