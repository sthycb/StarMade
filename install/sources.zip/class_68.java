import java.io.DataInputStream;

public abstract interface class_68
{
  public abstract Object create(DataInputStream paramDataInputStream);
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_68
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */