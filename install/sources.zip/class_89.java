import org.schema.schine.network.client.ClientState;

final class class_89
  extends class_1404
{
  class_89(class_85 paramclass_85, ClientState paramClientState)
  {
    super(paramClientState);
  }
  
  protected final void e()
  {
    this.field_89.a11().field_796 = 0;
  }
  
  protected final void f()
  {
    this.field_89.a11().field_796 = 1;
  }
  
  protected final boolean b3()
  {
    return this.field_89.a11().field_796 == 0;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_89
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */