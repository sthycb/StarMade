public final class class_426
  extends class_16
{
  public class_426(class_371 paramclass_371)
  {
    super(paramclass_371);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_426
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */