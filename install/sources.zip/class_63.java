public final class class_63
  extends class_59
{
  private static final long serialVersionUID = -8062062884428582893L;
  
  public class_63(Object paramObject, class_64 paramclass_64)
  {
    super(paramObject, paramclass_64);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_63
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */