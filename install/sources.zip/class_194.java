import org.schema.schine.network.client.ClientState;

public final class class_194
  extends class_972
{
  private final class_319 field_89;
  
  public class_194(class_1380 paramclass_1380, ClientState paramClientState, class_319 paramclass_319, String paramString, class_1412 paramclass_1412)
  {
    super(paramclass_1380, paramClientState);
    this.field_89 = paramclass_319;
    this.field_96 = true;
    this.field_89 = paramString;
    a141(paramclass_1412);
  }
  
  public final void b()
  {
    if (this.field_89) {
      return;
    }
    a_2(this.field_89.a(a_()));
    super.b();
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_194
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */