final class class_135
  implements class_1412
{
  class_135(class_131 paramclass_131) {}
  
  public final boolean a1()
  {
    return false;
  }
  
  public final void a(class_1363 paramclass_1363, class_939 paramclass_939)
  {
    if (paramclass_939.a()) {
      ((class_371)this.field_91.a24()).a45().a157(((class_371)this.field_91.a24()).getPlayerName(), class_131.a36(this.field_91), false);
    }
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_135
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */