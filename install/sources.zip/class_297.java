import com.bulletphysics.linearmath.Transform;

public final class class_297
  extends class_251
{
  public class_297(Transform paramTransform, String paramString)
  {
    super(paramTransform, paramString);
  }
  
  public final Transform a()
  {
    return this.field_104;
  }
  
  public final boolean a2()
  {
    return true;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_297
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */