import org.schema.schine.network.client.ClientState;

final class class_252
  extends class_1404
{
  class_252(class_244 paramclass_244, ClientState paramClientState)
  {
    super(paramClientState);
  }
  
  protected final boolean b3()
  {
    return this.field_89.field_89.a7();
  }
  
  protected final void f()
  {
    this.field_89.field_89.a189(false, 2);
  }
  
  protected final void e()
  {
    this.field_89.field_89.a189(true, 2);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_252
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */