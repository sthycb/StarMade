import java.net.URL;

public final class class_61
{
  public String field_527;
  public URL field_527;
  
  public class_61(String paramString, URL paramURL)
  {
    this.jdField_field_527_of_type_JavaLangString = paramString;
    this.jdField_field_527_of_type_JavaNetURL = paramURL;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_61
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */