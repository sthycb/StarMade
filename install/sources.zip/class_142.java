final class class_142
  implements class_1412
{
  class_142(class_177 paramclass_177) {}
  
  public final boolean a1()
  {
    return false;
  }
  
  public final void a(class_1363 paramclass_1363, class_939 paramclass_939)
  {
    if (paramclass_939.a())
    {
      ((class_371)this.field_91.a24()).a14().a18().a79().a59().e2(true);
      paramclass_1363 = ((class_371)this.field_91.a24()).a4().a32().field_770;
      (paramclass_1363 = new class_137((class_371)this.field_91.a24(), "Enter waypoint", "Enter waypoint (e.g. 10, 20, 111)", paramclass_1363 != null ? paramclass_1363.field_475 + ", " + paramclass_1363.field_476 + ", " + paramclass_1363.field_477 : "")).a10(new class_849());
      paramclass_1363.c1();
    }
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_142
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */