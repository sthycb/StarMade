public abstract interface class_377
{
  public abstract void a(String paramString);
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_377
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */