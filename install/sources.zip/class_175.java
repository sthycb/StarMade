final class class_175
  implements class_1412
{
  class_175(class_177 paramclass_177) {}
  
  public final boolean a1()
  {
    return false;
  }
  
  public final void a(class_1363 paramclass_1363, class_939 paramclass_939)
  {
    if (paramclass_939.a()) {
      new class_336((class_371)this.field_91.a24(), class_177.a66(this.field_91).a44()).c1();
    }
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_175
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */