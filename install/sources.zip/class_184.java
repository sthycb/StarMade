final class class_184
  implements class_1412
{
  class_184(class_160 paramclass_160) {}
  
  public final boolean a1()
  {
    return false;
  }
  
  public final void a(class_1363 paramclass_1363, class_939 paramclass_939)
  {
    if (paramclass_939.a()) {
      this.field_91.a51(class_180.field_629);
    }
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_184
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */