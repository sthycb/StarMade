import java.util.List;

public final class class_333
  extends class_73
{
  public static class_1395[] field_134;
  public static class_1395[] field_135;
  public static class_1395 field_134;
  public static class_1395 field_135;
  public static class_1391 field_134;
  public static class_925 field_134;
  
  public final List a()
  {
    List localList = super.a();
    localList.add(new class_335());
    localList.add(new class_321());
    localList.add(new class_323());
    localList.add(new class_325());
    localList.add(new class_327());
    localList.add(new class_315());
    localList.add(new class_313());
    return localList;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_333
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */