import java.util.HashSet;
import org.schema.game.common.data.world.Segment;

final class class_217
  implements class_888
{
  private class_217(class_219 paramclass_219) {}
  
  public final boolean handle(Segment paramSegment)
  {
    if ((paramSegment = (class_657)paramSegment).b6()) {
      class_219.a(this.field_105).add(paramSegment);
    }
    return !class_933.a1();
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_217
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */