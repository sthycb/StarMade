final class class_308
  implements class_952
{
  class_308(class_304 paramclass_304) {}
  
  public final void a(String paramString)
  {
    try
    {
      ((class_306)this.field_129.field_4).field_658 = (-Integer.parseInt(paramString));
      return;
    }
    catch (Exception localException) {}
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_308
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */