public final class class_60
  extends class_59
{
  private static final long serialVersionUID = -5610119959656087076L;
  
  public class_60(Object paramObject, class_64 paramclass_64)
  {
    super(paramObject, paramclass_64);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_60
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */