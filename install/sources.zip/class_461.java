public final class class_461
{
  public int field_802 = 1;
  
  public final String toString()
  {
    return String.valueOf(this.field_802);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_461
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */