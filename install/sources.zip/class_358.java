import com.bulletphysics.linearmath.Transform;

public final class class_358
{
  Transform jdField_field_708_of_type_ComBulletphysicsLinearmathTransform;
  boolean jdField_field_708_of_type_Boolean;
  
  public class_358(Transform paramTransform, boolean paramBoolean)
  {
    this.jdField_field_708_of_type_ComBulletphysicsLinearmathTransform = paramTransform;
    this.jdField_field_708_of_type_Boolean = paramBoolean;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_358
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */