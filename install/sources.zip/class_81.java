import it.unimi.dsi.fastutil.io.FastByteArrayInputStream;
import it.unimi.dsi.fastutil.io.FastByteArrayOutputStream;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

public final class class_81
{
  private byte[] field_563 = new byte[5242880];
  private byte[] field_564;
  
  public class_81()
  {
    new FastByteArrayInputStream(this.field_563);
    this.field_564 = new byte[5242880];
    new FastByteArrayOutputStream(this.field_564);
    new Deflater();
    new Inflater();
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_81
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */