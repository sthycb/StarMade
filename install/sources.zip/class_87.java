import org.schema.schine.network.client.ClientState;

final class class_87
  extends class_1404
{
  class_87(class_85 paramclass_85, ClientState paramClientState)
  {
    super(paramClientState);
  }
  
  protected final void e()
  {
    this.field_89.a10().field_7 = false;
  }
  
  protected final void f()
  {
    this.field_89.a10().field_7 = true;
  }
  
  protected final boolean b3()
  {
    return !this.field_89.a10().field_7;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_87
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */