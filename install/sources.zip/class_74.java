public abstract interface class_74
{
  public abstract String getUniqueIdentifier();
  
  public abstract boolean isVolatile();
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_74
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */