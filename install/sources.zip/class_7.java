import com.bulletphysics.collision.dispatch.CollisionWorld.ClosestRayResultCallback;
import com.bulletphysics.linearmath.Transform;

public abstract interface class_7
{
  public abstract void handleHit(CollisionWorld.ClosestRayResultCallback paramClosestRayResultCallback, class_809 paramclass_809, float paramFloat);
  
  public abstract void handleHitMissile(class_597 paramclass_597, Transform paramTransform);
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_7
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */