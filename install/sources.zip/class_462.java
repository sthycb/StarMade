public final class class_462
  extends class_997
{
  private static final long serialVersionUID = -2266101204277288192L;
  private class_999 jdField_field_164_of_type_Class_999;
  private class_999 field_165;
  private class_405 jdField_field_164_of_type_Class_405;
  
  public class_462(class_989 paramclass_989, class_983 paramclass_983)
  {
    super(paramclass_989, paramclass_983);
  }
  
  public final void a()
  {
    Object localObject = new class_395();
    class_385 localclass_385 = new class_385();
    class_391 localclass_391 = new class_391();
    class_393 localclass_393 = new class_393();
    class_371 localclass_371 = ((class_460)super.a1()).a1();
    this.jdField_field_164_of_type_Class_405 = new class_405(this.field_164);
    this.jdField_field_164_of_type_Class_999 = new class_300(this.field_164, localclass_371, "Hello and welcome to StarMade", 3000);
    this.field_165 = new class_399(this.field_164, localclass_371, "You completed the tutorial.\nThank you for playing!\nTo find out more about the game\ngo to www.star-made.org");
    this.jdField_field_164_of_type_Class_999.a9(localclass_393, this.field_165);
    this.field_165.a9(localclass_385, this.jdField_field_164_of_type_Class_999);
    this.jdField_field_164_of_type_Class_405.a9(localclass_385, this.jdField_field_164_of_type_Class_999);
    class_300 localclass_300 = new class_300(this.field_164, localclass_371, "Press 'ENTER' to chat\nto other players.\nAlso, you can use admin commands in single player\nor if you are admin on a multiplayer server.\nA list of commands can be\nfound at www.star-made.org/help", 3000);
    class_999 localclass_999;
    (localclass_999 = new class_464(this.jdField_field_164_of_type_Class_999, this.jdField_field_164_of_type_Class_999, this.field_165, localclass_371).a3()).a9(localclass_391, localclass_300);
    localclass_999.a9(new class_375(), this.jdField_field_164_of_type_Class_999);
    localclass_999.a9(localclass_385, this.jdField_field_164_of_type_Class_999);
    localclass_999.a9(localclass_393, this.field_165);
    localclass_300.a9(new class_375(), this.field_165);
    localclass_300.a9(new class_383(), localclass_999);
    localclass_300.a9(localclass_385, this.jdField_field_164_of_type_Class_999);
    localclass_300.a9(localclass_393, this.field_165);
    localclass_300.a9((class_1003)localObject, localclass_999);
    localObject = new class_458(localclass_300, this.jdField_field_164_of_type_Class_999, this.field_165, localclass_371).a3();
    localObject = new class_470((class_999)localObject, this.jdField_field_164_of_type_Class_999, this.field_165, localclass_371).a3();
    (localObject = new class_468((class_999)localObject, this.jdField_field_164_of_type_Class_999, this.field_165, localclass_371).a3()).a9(localclass_391, this.field_165);
    ((class_999)localObject).a9(localclass_385, this.jdField_field_164_of_type_Class_999);
    ((class_999)localObject).a9(localclass_393, this.field_165);
    this.field_165.a9(localclass_391, this.jdField_field_164_of_type_Class_405);
    a3(this.jdField_field_164_of_type_Class_999);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_462
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */