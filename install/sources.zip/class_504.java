import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import org.schema.game.common.crashreporter.CrashReportGUI;

final class class_504
  implements ActionListener
{
  public final void actionPerformed(ActionEvent paramActionEvent)
  {
    CrashReportGUI.main(new String[0]);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_504
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */