final class class_413
  extends class_346
{
  class_413(class_423 paramclass_423, class_371 paramclass_371, class_773 paramclass_773)
  {
    super(paramclass_371, paramclass_773);
  }
  
  public final void a2()
  {
    super.a2();
    this.field_4.e2(false);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_413
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */