final class class_498
  implements class_532
{
  public final void a() {}
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_498
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */