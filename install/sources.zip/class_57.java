public final class class_57
  extends class_59
{
  private static final long serialVersionUID = 7414765311357833461L;
  
  public class_57(Object paramObject, class_64 paramclass_64)
  {
    super(paramObject, paramclass_64);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_57
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */