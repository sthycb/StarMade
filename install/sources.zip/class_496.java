import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;

final class class_496
  implements ActionListener
{
  class_496(class_700 paramclass_700, JFrame paramJFrame) {}
  
  public final void actionPerformed(ActionEvent paramActionEvent)
  {
    paramActionEvent = new class_561();
    new class_546(this.jdField_field_812_of_type_JavaxSwingJFrame, paramActionEvent.field_866, paramActionEvent.field_867, new class_494(this, paramActionEvent)).setVisible(true);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_496
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */