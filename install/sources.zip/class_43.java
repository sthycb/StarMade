import org.schema.schine.network.client.ClientState;

public abstract class class_43
  extends class_1363
{
  public class_43(ClientState paramClientState)
  {
    super(paramClientState);
  }
  
  public abstract void a(float paramFloat);
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_43
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */