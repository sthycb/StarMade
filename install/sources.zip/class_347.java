import java.io.DataOutputStream;

public abstract interface class_347
  extends class_80, class_955
{
  public abstract void a2(DataOutputStream paramDataOutputStream);
  
  public abstract int a3();
  
  public abstract void a4(byte paramByte);
  
  public abstract boolean a5(int paramInt, class_48 paramclass_48);
  
  public abstract class_251 a6(class_48 paramclass_48);
  
  public abstract boolean a7();
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_347
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */