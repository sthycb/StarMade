import java.util.Collection;
import org.schema.schine.network.client.ClientState;

final class class_162
  extends class_160
{
  class_162(ClientState paramClientState, int paramInt)
  {
    super(paramClientState, paramInt, false);
  }
  
  public final Collection a50()
  {
    return ((class_371)a24()).a20().a122().field_1044;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_162
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */