import java.util.Comparator;

public final class class_230
  implements Comparator
{
  private boolean field_644;
  
  public class_230(boolean paramBoolean)
  {
    this.field_644 = paramBoolean;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_230
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */