final class class_143
{
  class_143(class_156 paramclass_156) {}
  
  public final String toString()
  {
    return class_156.a46(this.field_625);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_143
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */