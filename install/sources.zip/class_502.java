import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

final class class_502
  implements ActionListener
{
  class_502(class_700 paramclass_700) {}
  
  public final void actionPerformed(ActionEvent paramActionEvent)
  {
    this.field_817.dispose();
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_502
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */