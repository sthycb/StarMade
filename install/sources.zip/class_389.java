public final class class_389
  extends class_1003
{
  private static final long serialVersionUID = 1L;
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_389
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */