final class class_256
  extends class_13
{
  class_256(class_371 paramclass_371, Object paramObject1, Object paramObject2, int paramInt)
  {
    super(paramclass_371, paramObject1, paramObject2);
  }
  
  public final boolean a1()
  {
    return false;
  }
  
  public final void b()
  {
    this.field_4.a20().a141().b6(this.field_4);
    d();
  }
  
  public final void a2() {}
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_256
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */