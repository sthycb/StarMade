public final class class_425
  extends class_16
{
  public class_425(class_371 paramclass_371)
  {
    super(paramclass_371);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_425
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */