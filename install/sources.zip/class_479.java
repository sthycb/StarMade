public abstract interface class_479
{
  public abstract void a(class_48 paramclass_481, class_48 paramclass_482, short paramShort);
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_479
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */