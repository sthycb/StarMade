import javax.vecmath.Vector3f;

public final class class_317
  extends class_935
{
  private static float field_131;
  
  public final float a()
  {
    return field_131;
  }
  
  public final void a1()
  {
    field_131 = new Vector3f(a2() << 4, a2() << 4, a2() << 4).length();
    class_876.a();
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_317
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */