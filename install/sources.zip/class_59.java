import java.io.Serializable;

public class class_59
  implements Serializable
{
  private static final long serialVersionUID = -6331218458640407293L;
  private Object jdField_field_526_of_type_JavaLangObject;
  class_64 jdField_field_526_of_type_Class_64;
  
  public class_59(Object paramObject, class_64 paramclass_64)
  {
    this.jdField_field_526_of_type_JavaLangObject = paramObject;
    this.jdField_field_526_of_type_Class_64 = paramclass_64;
  }
  
  public final Object a()
  {
    return this.jdField_field_526_of_type_JavaLangObject;
  }
  
  public String toString()
  {
    return this.jdField_field_526_of_type_JavaLangObject.toString();
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_59
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */