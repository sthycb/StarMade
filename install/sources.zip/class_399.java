public final class class_399
  extends class_300
{
  private static final long serialVersionUID = 6050895723297381559L;
  
  public class_399(class_981 paramclass_981, class_371 paramclass_371, String paramString)
  {
    super(paramclass_981, paramclass_371, paramString, 3000);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_399
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */