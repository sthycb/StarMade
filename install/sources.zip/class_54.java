public final class class_54
{
  public String field_520;
  public String field_521;
  
  public class_54(String paramString1, String paramString2)
  {
    this.field_520 = paramString1;
    this.field_521 = paramString2;
  }
  
  public final String toString()
  {
    return this.field_520;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_54
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */