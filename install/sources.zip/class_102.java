import org.schema.schine.network.client.ClientState;

final class class_102
  extends class_1404
{
  class_102(class_244 paramclass_244, ClientState paramClientState)
  {
    super(paramClientState);
  }
  
  protected final boolean b3()
  {
    return this.field_89.field_89.d10();
  }
  
  protected final void f()
  {
    this.field_89.field_89.a189(false, 16);
  }
  
  protected final void e()
  {
    this.field_89.field_89.a189(true, 16);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_102
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */