final class class_268
  implements class_1412
{
  class_268(class_272 paramclass_272) {}
  
  public final void a(class_1363 paramclass_1363, class_939 paramclass_939)
  {
    if ((paramclass_939.jdField_field_1163_of_type_Boolean) && (paramclass_939.jdField_field_1163_of_type_Int == 0))
    {
      paramclass_1363 = this.field_91.a28().a28();
      this.field_91.a28().a54();
      paramclass_1363 = (paramclass_1363 + 1) % class_272.a110(this.field_91);
      this.field_91.a28().c3(paramclass_1363);
      class_272.a111(this.field_91);
    }
  }
  
  public final boolean a1()
  {
    return false;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_268
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */