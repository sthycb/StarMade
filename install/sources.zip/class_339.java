public class class_339
{
  public class_48 field_683;
  public byte field_683;
  public class_347[] field_683;
  
  public class_339() {}
  
  public class_339(byte paramByte, class_48 paramclass_48)
  {
    this.jdField_field_683_of_type_Byte = paramByte;
    this.jdField_field_683_of_type_Class_48 = paramclass_48;
  }
  
  public boolean equals(Object paramObject)
  {
    return (this.jdField_field_683_of_type_Byte == ((class_339)paramObject).jdField_field_683_of_type_Byte) && (this.jdField_field_683_of_type_Class_48.equals(((class_339)paramObject).jdField_field_683_of_type_Class_48));
  }
  
  public int hashCode()
  {
    return this.jdField_field_683_of_type_Byte * 90000 + this.jdField_field_683_of_type_Class_48.hashCode();
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_339
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */