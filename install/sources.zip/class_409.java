import java.io.PrintStream;

final class class_409
  extends class_13
{
  class_409(class_371 paramclass_371, Object paramObject1, Object paramObject2)
  {
    super(paramclass_371, paramObject1, paramObject2);
  }
  
  public final boolean a1()
  {
    return false;
  }
  
  public final void b()
  {
    System.err.println("[CLIENT][FactionControlManager] leaving Faction");
    this.field_4.a20().a141().c1();
    d();
  }
  
  public final void a2() {}
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_409
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */