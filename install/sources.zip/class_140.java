final class class_140
{
  class_140(class_177 paramclass_177) {}
  
  public final String toString()
  {
    class_48 localclass_48;
    if ((localclass_48 = ((class_371)this.field_624.a24()).a4().a32().field_770) != null) {
      return "to: " + localclass_48;
    }
    return "No waypoint";
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_140
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */