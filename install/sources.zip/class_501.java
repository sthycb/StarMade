import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

final class class_501
  implements ActionListener
{
  class_501(class_699 paramclass_699) {}
  
  public final void actionPerformed(ActionEvent paramActionEvent)
  {
    class_699.b(this.field_816);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_501
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */