final class class_421
  implements class_956
{
  public final boolean a(String paramString, class_1079 paramclass_1079)
  {
    if (class_1070.a4(paramString)) {
      return true;
    }
    paramclass_1079.onFailedTextCheck("Must only contain Letters or numbers or (_-)!");
    return false;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_421
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */