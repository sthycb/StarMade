final class class_265
{
  class_265(class_263 paramclass_263) {}
  
  public final String toString()
  {
    return "(Characters Left: " + (class_263.a109(this.field_654).c4() - class_263.a109(this.field_654).a4().length()) + "/" + class_263.a109(this.field_654).c4() + "; New Lines Left: " + (class_263.a109(this.field_654).d5() - class_263.a109(this.field_654).a28() - 1) + "/" + (class_263.a109(this.field_654).d5() - 1) + ")";
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_265
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */