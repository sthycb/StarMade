final class class_169
{
  class_169(class_171 paramclass_171) {}
  
  public final String toString()
  {
    return class_171.a55(this.field_626).a180().a26()[class_171.a56(this.field_626).field_136];
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_169
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */