final class class_432
  extends class_422
{
  class_432(class_431 paramclass_431, class_371 paramclass_371, class_797 paramclass_797)
  {
    super(paramclass_371, paramclass_797);
  }
  
  public final void a2()
  {
    this.field_4.a13(400);
    this.field_4.e2(false);
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_432
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */