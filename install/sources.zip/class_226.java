import javax.vecmath.Vector3f;

public final class class_226
  extends class_1357
{
  Vector3f field_9 = new Vector3f();
  
  public final boolean a7(int paramInt, class_941 paramclass_941)
  {
    return true;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_226
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */