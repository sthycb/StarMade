final class class_204
  implements class_1412
{
  class_204(class_82 paramclass_82) {}
  
  public final void a(class_1363 paramclass_1363, class_939 paramclass_939)
  {
    paramclass_1363 = null;
    if ((paramclass_939.jdField_field_1163_of_type_Boolean) && (paramclass_939.jdField_field_1163_of_type_Int == 0))
    {
      (paramclass_1363 = class_82.a5(this.field_91)).field_802 = Math.min(10, paramclass_1363.field_802 + 1);
      class_82.a6(this.field_91);
    }
  }
  
  public final boolean a1()
  {
    return false;
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_204
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */