final class class_96
{
  class_96(class_101 paramclass_101, class_773 paramclass_773) {}
  
  public final String toString()
  {
    if ((this.jdField_field_621_of_type_Class_773.a3() < 0) || (this.jdField_field_621_of_type_Class_773.a3() == ((class_371)this.jdField_field_621_of_type_Class_101.a24()).a20().a141().a3())) {
      return "        -";
    }
    if (this.jdField_field_621_of_type_Class_773.c3()) {
      return "join";
    }
    return "private";
  }
}


/* Location:           C:\Users\Raul\Desktop\StarMadeDec\StarMadeR.zip
 * Qualified Name:     class_96
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */